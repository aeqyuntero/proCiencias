#ifndef ARCHIVOSUCURSAL_H
#define ARCHIVOSUCURSAL_H
#include<iostream>
#include<stdio.h>
#include<fstream>
#include<string.h>
#include "lista.h"
using namespace std;

struct Sucursal{
	string nombre, nomGerente, apeGerente, localidad;
	int calleInicio, calleFin, carreraInicio, carreraFin;
	lista<string> Paseadores;
	lista<string> Clientes;	
}s;

class ArchivoSucursal{
	public:
		void guardarSucursal(Sucursal s);
		bool buscarSucursal(Sucursal s);		
};

bool ArchivoSucursal::buscarSucursal(Sucursal s){
	string name, callein, callef, carrerain, carreraf;
	int tamanoPaseador=s.Paseadores.get_tam()+1;
	int tamanoCliente=s.Clientes.get_tam()+1;
	string idPaseadores[100];
	string idClientes[100];
	ifstream archivoLeer;
	archivoLeer.open("sucursales.txt",ios::in);
	while(!archivoLeer.eof()){
		archivoLeer>>name>>s.nomGerente>>s.apeGerente>>s.localidad>>callein>>callef>>carrerain>>carreraf>>idPaseadores[0];
		for(int i=1; i<tamanoPaseador; i++){
			archivoLeer>>idPaseadores[i];
		}
		archivoLeer>>idClientes[0];
		for(int i=1; i<tamanoCliente; i++){
			archivoLeer>>idClientes[i];
		}
		if(s.nombre==name){
			return true;
		}
	}
	archivoLeer.close();
	return false;
}

void ArchivoSucursal::guardarSucursal(Sucursal s){
	string name, callein, callef, carrerain, carreraf, aux, aux2;
	int tamanoPaseador=s.Paseadores.get_tam()+1;
	int tamanoCliente=s.Clientes.get_tam()+1, i;
	string idPaseadores[100];
	string idClientes[100];
	ofstream archivoEditar;
	ifstream archivoLeer;
	Sucursal s1;
	bool ingreso=true;
	archivoEditar.open("sucursales.txt",ios::app);
	archivoEditar.close();
	if (buscarSucursal(s)){
		archivoLeer("sucursales.txt",ios::in);
		archivoEditar("temp.txt",ios::out);
		while(!archivoLeer.eof()){
			archivoLeer>>name>>s1.nomGerente>>s1.apeGerente>>s1.localidad>>callein>>callef>>carrerain>>carreraf>>idPaseadores[0];
			i=0;
			while(ingreso){
				i++;
				archivoLeer>>aux;
				if (aux!="+Clientes"){
					idPaseadores[i]=aux;
				}else{
					ingreso=false;
				}
			}
			i=0;
			ingreso=true;
			while(ingreso){
				i++;
				archivoLeer>>aux2;
				if (aux2[0]!=47){
					idClientes[i]=aux2;
				}else{
					ingreso=false;
				}
			}
			if (name!=s.nombre){
				archivoEditar<<"/"<<s1.nombre<<" "<<s1.nomGerente<<" "<<s1.apeGerente<<" "<<s1.localidad<<" ";
				archivoEditar<<callein<<" "<<callef<<" "<<carrerain<<" "<<carreraf<<" ";
				archivoEditar<<"-Paseadores"<<" ";
				idPaseadores[0]="";
				for (int i=1; i<idPaseadores.length(); i++){
					archivoEditar<<idPaseadores[i]<<" ";
					idPaseadores[i]="";
				}
				archivoEditar<<"+Clientes"<<" ";
				idClientes[0]="";
				for (int i=1; i<idClientes.length(); i++){
					if (i<idClientes.length()-1){
						archivoEditar<<idClientes[i]<<" ";
					}else{
						archivoEditar<<idClientes[i]<<endl;
					}
					idClientes[i]="";
				}
			}else{
				archivoEditar<<s.nombre<<" "<<s.nomGerente<<" "<<s.apeGerente<<" "<<s.localidad<<" ";
				archivoEditar<<s.calleInicio<<" "<<s.calleFin<<" "<<s.carreraInicio<<" "<<s.carreraFin<<" ";
				archivoEditar<<"-Paseadores"<<" ";
				for (int i=0; i<s.Paseadores.get_tam(); i++){
					archivoEditar<<s.Paseadores.buscar(i)<<" ";
				}
				archivoEditar<<"+Clientes"<<" ";
				for (int i=0; i<s.Clientes.get_tam(); i++){
					if (i<s.Clientes.get_tam()-1){
						archivoEditar<<s.Clientes.buscar(i)<<" ";
					}else{
						archivoEditar<<s.Clientes.buscar(i)<<endl;
					}
				}
			}
		}
		archivoLeer.close();
		archivoEditar.close();
		remove("sucursales.txt");
		rename("temp.txt","sucursales.txt");
	}else{
		archivoEditar.open("sucursales.txt",ios::app);
		archivoEditar<<s.nombre<<" "<<s.nomGerente<<" "<<s.apeGerente<<" "<<s.localidad<<" ";
		archivoEditar<<s.calleInicio<<" "<<s.calleFin<<" "<<s.carreraInicio<<" "<<s.carreraFin<<" ";
		archivoEditar<<"-Paseadores"<<" ";
		for (int i=0; i<s.Paseadores.get_tam(); i++){
			archivoEditar<<s.Paseadores.buscar(i)<<" ";
		}
		archivoEditar<<"+Clientes"<<" ";
		for (int i=0; i<s.Clientes.get_tam(); i++){
			if (i<s.Clientes.get_tam()-1){
				archivoEditar<<s.Clientes.buscar(i)<<" ";
			}else{
				archivoEditar<<s.Clientes.buscar(i)<<endl;
			}
		}
		archivoEditar.close();
	}
}

#endif



