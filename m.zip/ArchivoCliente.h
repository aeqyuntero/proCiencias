#ifndef ARCHIVOSUCURSAL_H
#define ARCHIVOSUCURSAL_H
#include<iostream>
#include<stdio.h>
#include<fstream>
#include<string.h>
#include "lista.h"
#include "Cliente.h"
using namespace std;

class ArchivoCliente{
	public:
		void agregarCliente(Cliente c);
};

void agregarCliente(Cliente c){
	string duracion;
	int tamanoLista = c.listaMascota.get_tam();
	string perros[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		perros[i-1] = c.listaMascota.buscar(i).nombreMascota;
	}
	int edades[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		edades[i-1] = c.listaMascota.buscar(i).edadMas;
	}
	string razas[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		razas[i-1] = c.listaMascota.buscar(i).raza;
	}
	string tiposConcentrado[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		tiposConcentrado[i-1] = c.listaMascota.buscar(i).tipoConcentrado;
	}
	char tamanio[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		tamanio[i-1] = c.listaMascota.buscar(i).tam;
	}
	string nombrePas[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		tamanio[i-1] = c.listaMascota.buscar(i).resumen.buscar(i).nombrePaseador;
	}
	string fechas[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		fechas[i-1] = c.listaMascota.buscar(i).resumen.buscar(i).fecha;
	}
	string horas[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		horas[i-1] = c.listaMascota.buscar(i).resumen.buscar(i).hora;
	}
	int horaDura[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		horaDura[i-1] = c.listaMascota.buscar(i).resumen.buscar(i).duracion;
	}
	string actividades[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		actividades[i-1] = c.listaMascota.buscar(i).resumen.buscar(i).actividad;
	}
	string obs[tamanoLista];
	for (int i=1; i<=tamanoLista; i++){
		obs[i-1] = c.listaMascota.buscar(i).resumen.buscar(i).observaciones;
	}
}
